//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Bill_Demo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BILL_DEMO_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     130
#define IDB_BITMAP2                     131
#define IDB_BITMAP3                     132
#define IDC_BILLSTATUSMSG               1000
#define IDC_CHECK1                      1001
#define IDC_AUTOSTACK                   1001
#define IDC_CHECK2                      1002
#define IDC_USE50WON                    1002
#define IDC_USEEVENT                    1003
#define IDC_WON1000                     1004
#define IDC_WON5000                     1005
#define IDC_CHECK3                      1006
#define IDC_USE10WON                    1006
#define IDC_CHECK4                      1007
#define IDC_USE5WON                     1007
#define IDC_CHECK5                      1008
#define IDC_USE1WON                     1008
#define IDC_WON10000                    1009
#define IDC_BUTTON1                     1010
#define IDC_BUTTON2                     1011
#define IDC_COMBO1                      1012
#define IDC_COMINTERVAL                 1013
#define IDC_BUTTON3                     1014
#define IDC_BUTTON4                     1015
#define IDC_BUTTON5                     1016
#define IDC_INHIBIT                     1016
#define IDC_STATUSMSG                   1017
#define IDC_9600BPS                     1018
#define IDC_4800BPS                     1019
#define IDC_ENABLE                      1020
#define IDC_BUTTON12                    1020
#define IDC_CHGPORT                     1021
#define IDC_BUTTON7                     1022
#define IDC_BUTTON8                     1023
#define IDC_BUTTON9                     1024
#define IDC_BUTTON10                    1025
#define IDC_BUTTON20                    1025
#define IDC_BUTTON11                    1026
#define IDC_AMOUNT50WON                 1027
#define IDC_AMOUNT10WON                 1028
#define IDC_AMOUNT5WON                  1029
#define IDC_AMOUNT1WON                  1030
#define IDC_VERSION                     1031
#define IDC_TX                          1032
#define IDC_RX                          1033
#define IDC_BUTTON6                     1036
#define IDC_BCNT1                       1037
#define IDC_BCNT5                       1038
#define IDC_BCNT10                      1039
#define IDC_BCNT50                      1040
#define IDC_EDIT1                       1041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
